import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-travel',
  templateUrl: './view-travel.component.html',
  styleUrls: ['./view-travel.component.scss']
})
export class ViewTravelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
