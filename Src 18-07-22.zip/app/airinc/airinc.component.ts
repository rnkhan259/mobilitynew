import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airinc',
  templateUrl: './airinc.component.html',
  styleUrls: ['./airinc.component.scss']
})
export class AirincComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
