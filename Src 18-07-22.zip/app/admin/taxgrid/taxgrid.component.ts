import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taxgrid',
  templateUrl: './taxgrid.component.html',
  styleUrls: ['./taxgrid.component.scss']
})
export class TaxgridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
