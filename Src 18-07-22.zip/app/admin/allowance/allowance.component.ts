import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allowance',
  templateUrl: './allowance.component.html',
  styleUrls: ['./allowance.component.scss']
})
export class AllowanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
