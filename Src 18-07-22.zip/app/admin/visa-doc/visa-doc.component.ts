import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa-doc',
  templateUrl: './visa-doc.component.html',
  styleUrls: ['./visa-doc.component.scss']
})
export class VisaDocComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
