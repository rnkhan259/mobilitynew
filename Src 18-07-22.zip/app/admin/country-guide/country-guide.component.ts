import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-guide',
  templateUrl: './country-guide.component.html',
  styleUrls: ['./country-guide.component.scss']
})
export class CountryGuideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
