import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-travel',
  templateUrl: './add-travel.component.html',
  styleUrls: ['./add-travel.component.scss']
})
export class AddTravelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
