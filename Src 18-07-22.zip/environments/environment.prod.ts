export const environment = {
  production: true,
  baseUrl: 'https://devapi.mobilitysqr.net',
};
